#include <cstdio>
#include <simple_library.h>

int main() {
    printf("Hello World");
    hello_world();

    return 0;
}
