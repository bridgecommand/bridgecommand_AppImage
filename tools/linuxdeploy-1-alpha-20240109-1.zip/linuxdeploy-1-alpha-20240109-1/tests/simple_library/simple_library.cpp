#include "CImg.h"
using namespace cimg_library;

void hello_world() {
    cimg::info();
}
